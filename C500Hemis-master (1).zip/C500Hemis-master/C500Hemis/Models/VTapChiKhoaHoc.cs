﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VTapChiKhoaHoc
{
    public string? MaTapChi { get; set; }

    public string? TenTapChiTiengViet { get; set; }

    public string? TenTapChiTiengAnh { get; set; }

    public string? MaChuanIssn { get; set; }

    public string? LinhVucNghienCuu { get; set; }

    public string? TapChiTrongNuoc { get; set; }

    public int? SoBaiBao1Nam { get; set; }
}
