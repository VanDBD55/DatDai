﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VPhongThucHanh
{
    public string? MaCongTrinh { get; set; }

    public string? LinhVucNghienCuu { get; set; }

    public string? MucDoDapUngNhuCauNckh { get; set; }

    public string? NamDuaVaoSuDung { get; set; }
}
