﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VThongTinNguoiHocGdtc
{
    public string? Ho { get; set; }

    public string? Ten { get; set; }

    public string? SoCccd { get; set; }

    public string? KetQuaHocTap { get; set; }

    public string? TieuChuanDanhGiaXepLoaiTheLuc { get; set; }
}
