﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VDatDai
{
    public string? MaGiayChungNhanQuyenSoHuu { get; set; }

    public double? DienTichDat { get; set; }

    public string? HinhThucSoHuu { get; set; }

    public string? TenDonViSoHuu { get; set; }

    public string? MinhChungQuyenSoHuuDatDai { get; set; }

    public string? MucDichSuDungDat { get; set; }

    public string? NamBatDauSuDungDat { get; set; }

    public int? ThoiGianSuDungDat { get; set; }

    public double? DienTichDatDaSuDung { get; set; }
}
