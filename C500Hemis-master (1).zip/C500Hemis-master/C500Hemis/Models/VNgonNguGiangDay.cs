﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VNgonNguGiangDay
{
    public string? TenChuongTrinh { get; set; }

    public string? MaChuongTrinhDaoTao { get; set; }

    public string? NgoaiNgu { get; set; }

    public string? TenKhungNangLucNgoaiNgu { get; set; }
}
