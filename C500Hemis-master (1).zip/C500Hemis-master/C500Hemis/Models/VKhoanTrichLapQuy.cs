﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VKhoanTrichLapQuy
{
    public string? MaKhoanTrichLapQuy { get; set; }

    public string? TenKhoanTrichLapQuy { get; set; }

    public string? NamTaiChinh { get; set; }

    public int? SoTien { get; set; }
}
