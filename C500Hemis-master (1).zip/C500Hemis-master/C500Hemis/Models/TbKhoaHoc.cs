﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class TbKhoaHoc
{
    public int IdKhoaHoc { get; set; }

    public string? TuNam { get; set; }

    public string? DenNam { get; set; }
}
