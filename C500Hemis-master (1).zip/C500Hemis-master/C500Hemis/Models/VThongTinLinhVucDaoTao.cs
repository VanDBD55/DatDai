﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VThongTinLinhVucDaoTao
{
    public string? KhoiNganhDaoTao { get; set; }

    public string? LinhVucDaoTao { get; set; }
}
