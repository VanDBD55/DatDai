﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VChiTieuTuyenSinhTheoNganh
{
    public string? LoaiHinhDaoTao { get; set; }

    public string? NganhDaoTao { get; set; }

    public string? Nam { get; set; }

    public int? ChiTieu { get; set; }
}
