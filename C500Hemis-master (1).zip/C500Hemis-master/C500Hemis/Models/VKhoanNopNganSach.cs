﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VKhoanNopNganSach
{
    public string? MaKhoanNop { get; set; }

    public string? TenKhoanNopNganSach { get; set; }

    public int? SoTien { get; set; }

    public string? NamTaiChinh { get; set; }
}
