﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VHinhThucDaoTaoCuaNganh
{
    public string? NganhDaoTao { get; set; }

    public string? HinhThucDaoTao { get; set; }

    public int? SoNamDaoTao { get; set; }
}
