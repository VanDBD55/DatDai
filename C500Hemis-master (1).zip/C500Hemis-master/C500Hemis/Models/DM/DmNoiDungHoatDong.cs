﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmNoiDungHoatDong
{
    public int IdNoiDungHoatDong { get; set; }

    public string? NoiDungHoatDong { get; set; }
}
