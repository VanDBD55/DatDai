﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmChucDanhHoiDong
{
    public int IdChucDanhHoiDong { get; set; }

    public string? ChucDanhHoiDong { get; set; }
}
