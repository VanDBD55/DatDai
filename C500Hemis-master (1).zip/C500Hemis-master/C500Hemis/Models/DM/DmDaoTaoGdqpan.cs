﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmDaoTaoGdqpan
{
    public int IdDaoTaoGdqpan { get; set; }

    public string? DaoTaoGdqpan { get; set; }
}
