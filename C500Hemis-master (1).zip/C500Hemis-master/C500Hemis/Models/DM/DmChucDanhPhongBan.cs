﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmChucDanhPhongBan
{
    public int IdChucDanhPhongBan { get; set; }

    public string? ChucDanhPhongBan { get; set; }
}
