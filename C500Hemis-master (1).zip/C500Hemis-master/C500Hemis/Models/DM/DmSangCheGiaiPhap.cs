﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmSangCheGiaiPhap
{
    public int IdSangCheGiaiPhap { get; set; }

    public string? TenLoaiGiaiPhap { get; set; }
}
