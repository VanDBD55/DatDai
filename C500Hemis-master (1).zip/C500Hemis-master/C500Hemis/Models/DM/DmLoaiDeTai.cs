﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmLoaiDeTai
{
    public int IdLoaiDeTai { get; set; }

    public string? LoaiDeTai { get; set; }
}
