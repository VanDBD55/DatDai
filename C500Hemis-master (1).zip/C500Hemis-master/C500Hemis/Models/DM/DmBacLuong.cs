﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmBacLuong
{
    public int IdBacLuong { get; set; }

    public string? BacLuong { get; set; }
}
