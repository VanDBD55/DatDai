﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmHinhThucDaoTaoTheoChuyenNgu
{
    public int IdHinhThucDaoTaoTheoChuyenNgu { get; set; }

    public string? HinhThucDaoTaoTheoChuyenNgu { get; set; }
}
