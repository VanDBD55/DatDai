﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmTrangThaiThucHien
{
    public int IdTrangThaiThucHien { get; set; }

    public string? TrangThaiThucHien { get; set; }
}
