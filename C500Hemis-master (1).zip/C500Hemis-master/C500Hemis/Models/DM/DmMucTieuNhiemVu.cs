﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmMucTieuNhiemVu
{
    public int IdMucTieuNhiemVu { get; set; }

    public string? MucTieuNhiemVu { get; set; }
}
