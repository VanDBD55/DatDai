﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VTaiSanDonVi
{
    public string? MaLoaiTaiSan { get; set; }

    public string? TenLoaiTaiSan { get; set; }

    public string? MoTa { get; set; }

    public string? NamTaiChinh { get; set; }
}
