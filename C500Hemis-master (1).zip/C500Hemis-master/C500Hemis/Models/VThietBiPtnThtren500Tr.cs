﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VThietBiPtnThtren500Tr
{
    public string? MaThietBi { get; set; }

    public string? MaCongTrinh { get; set; }

    public string? TenThietBi { get; set; }

    public string? NamSanXuat { get; set; }

    public string? TenNuoc { get; set; }

    public string? HangSanXuat { get; set; }

    public int? SoLuongThietBiCungLoai { get; set; }

    public string? NamDuaVaoSuDung { get; set; }
}
