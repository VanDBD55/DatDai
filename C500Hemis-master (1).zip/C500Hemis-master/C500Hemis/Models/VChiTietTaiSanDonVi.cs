﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VChiTietTaiSanDonVi
{
    public string? MaLoaiTaiSan { get; set; }

    public string? MaTaiSan { get; set; }

    public string? TenTaiSan { get; set; }

    public int? NguyenGia { get; set; }

    public string? TinhTrangThietBi { get; set; }

    public string? ChuSoHuu { get; set; }
}
