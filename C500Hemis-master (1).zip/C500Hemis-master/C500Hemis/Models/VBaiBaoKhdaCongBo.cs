﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VBaiBaoKhdaCongBo
{
    public string? MaNhiemVu { get; set; }

    public string? MaBaiBaoKh { get; set; }

    public string? TenBaiBaoKh { get; set; }

    public string? TenTapChi { get; set; }

    public string? TapChiTrongNuoc { get; set; }

    public string? TapChiKhoaHocQuocTe { get; set; }

    public string? XepHangQ { get; set; }

    public string? GhiChuDuongDanBaiBao { get; set; }

    public int? TapSo { get; set; }

    public int? Trang { get; set; }

    public string? NamCongBo { get; set; }
}
