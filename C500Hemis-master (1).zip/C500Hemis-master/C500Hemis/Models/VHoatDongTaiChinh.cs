﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VHoatDongTaiChinh
{
    public string? HoatDongTaiChinh { get; set; }

    public string? NamTaiChinh { get; set; }

    public int? KinhPhi { get; set; }

    public string? NoiDung { get; set; }
}
