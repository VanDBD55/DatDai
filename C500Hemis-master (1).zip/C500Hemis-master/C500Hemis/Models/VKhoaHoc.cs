﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VKhoaHoc
{
    public string? TuNam { get; set; }

    public string? DenNam { get; set; }
}
