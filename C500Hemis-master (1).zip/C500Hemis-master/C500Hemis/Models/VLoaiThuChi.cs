﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VLoaiThuChi
{
    public string? MaLoaiThuChi { get; set; }

    public string? PhanLoaiThuChi { get; set; }

    public string? TenLoaiThuChi { get; set; }

    public string? MoTa { get; set; }
}
